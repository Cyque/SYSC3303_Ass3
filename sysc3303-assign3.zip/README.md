# SYSC3303_Ass3

To run 

Part 1: 
run main inside of testAll.java

Part 2:
execute the following unix commands.
	make
	./main