
Authors: Nate Bosscher, Damian Polan

Compilation & Run: execute the following unix commands.

	make
	./main


